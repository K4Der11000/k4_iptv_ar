from flask import Flask, render_template, request, redirect, session, url_for
import requests
import re

app = Flask(__name__)
app.secret_key = 'secret-key-kader11000'

PASSWORD = 'kader11000'

COUNTRIES = {
    "السعودية": "https://iptv-org.github.io/iptv/countries/sa.m3u",
    "مصر": "https://iptv-org.github.io/iptv/countries/eg.m3u",
    "المغرب": "https://iptv-org.github.io/iptv/countries/ma.m3u",
    "الجزائر": "https://iptv-org.github.io/iptv/countries/dz.m3u",
    "الإمارات": "https://iptv-org.github.io/iptv/countries/ae.m3u",
    "العراق": "https://iptv-org.github.io/iptv/countries/iq.m3u",
    "تونس": "https://iptv-org.github.io/iptv/countries/tn.m3u",
    "لبنان": "https://iptv-org.github.io/iptv/countries/lb.m3u",
    "سوريا": "https://iptv-org.github.io/iptv/countries/sy.m3u",
    "فلسطين": "https://iptv-org.github.io/iptv/countries/ps.m3u",
}

def fetch_channels():
    all_channels = {}
    for country, url in COUNTRIES.items():
        try:
            res = requests.get(url)
            matches = re.findall(r'#EXTINF:-1.*?tvg-logo="(.*?)".*?,(.*?)\n(https?://.*?)\n', res.text)
            channels = [{"name": name, "logo": logo, "url": stream} for logo, name, stream in matches]
            all_channels[country] = channels
        except:
            all_channels[country] = []
    return all_channels

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if request.form['password'] == PASSWORD:
            session['authenticated'] = True
            return redirect(url_for('home'))
    return render_template('login.html')

@app.route('/home')
def home():
    if not session.get('authenticated'):
        return redirect(url_for('login'))
    channels_by_country = fetch_channels()
    return render_template('index.html', channels=channels_by_country)

@app.route('/logout')
def logout():
    session.pop('authenticated', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)